<!DOCTYPE html>
<html lang="en">
   @include('components/header')
   @include('components/navbar')
<body>
</body>
</html>