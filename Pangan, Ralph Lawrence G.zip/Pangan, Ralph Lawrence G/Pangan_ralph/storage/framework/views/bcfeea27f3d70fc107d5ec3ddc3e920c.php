<nav class="navbar bg-light fixed-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">MAH HOMIE MAH FREN</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
        <div class="offcanvas-header">
          <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Ralph Lawrence G. Pangan</h5>
          <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#">RALPH</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">PANGAN</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                GWENCHANAYO
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Action</a></li>
                <li><a class="dropdown-item" href="#">Another action</a></li>
                <li>
                  <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="#">Something else here</a></li>
              </ul>
            </li>
          </ul>
          <form class="d-flex mt-3" role="DANA">
            <input class="form-control me-2" type="DANA" placeholder="DANA" aria-label="DANA">
            <button class="btn btn-outline-success" type="submit">mag type ka</button>
          </form>
        </div>
      </div>
    </div>
  </nav>

  <div class="list-group">
    <a href="#" class="list-group-item list-group-item-action active" aria-current="true">
      The current link item
    </a>
    <a href="#" class="list-group-item list-group-item-action">RALPH</a>
    <a href="#" class="list-group-item list-group-item-action">LAWRENCE</a>
    <a href="#" class="list-group-item list-group-item-action">GRAN</a>
    <a class="list-group-item list-group-item-action disabled">PANGAN</a>
  </div>
  <span class="badge text-bg-primary">Primary</span>
  <span class="badge text-bg-info">Info</span>
  
  <button type="button" class="btn btn-primary">Primary</button>
<button type="button" class="btn btn-secondary">Secondary</button>
<button type="button" class="btn btn-success">Success</button>
<button type="button" class="btn btn-danger">Danger</button>
<button type="button" class="btn btn-warning">Warning</button>
<button type="button" class="btn btn-info">Info</button>
<button type="button" class="btn btn-light">Light</button>
<button type="button" class="btn btn-dark">Dark</button>

<button type="button" class="btn btn-link">Link</button><?php /**PATH D:\Pangan, Ralph Lawrence G\Pangan_ralph\resources\views/components/navbar.blade.php ENDPATH**/ ?>