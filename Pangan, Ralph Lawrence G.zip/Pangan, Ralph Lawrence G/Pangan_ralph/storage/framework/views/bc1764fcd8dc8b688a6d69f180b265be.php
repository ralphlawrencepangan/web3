<!DOCTYPE html>
<html lang="en">
   <?php echo $__env->make('components/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
</body>
</html><?php /**PATH D:\Pangan, Ralph Lawrence G\Pangan_ralph\resources\views/dashboard.blade.php ENDPATH**/ ?>